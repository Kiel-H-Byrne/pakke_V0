import React from 'react';
import PropTypes from 'prop-types';
import { Accounts } from 'meteor/accounts-base';

import { Button as MButton } from '@material-ui/core/Button'
import { Facebook, Google, GooglePlus } from 'mdi-material-ui'

let Link;
try { Link = require('react-router').Link; } catch(e) {}

export class Button extends React.Component {
  render () {
    const {
      label,
      href = null,
      type,
      disabled = false,
      className,
      onClick,
    } = this.props;
    if (type == 'link') {
      // Support React Router.
      if (Link && href) {
        return (
                <MButton
                variant="contained"
                href={ href } 
                className={ className }
                >
                {React.createElement(label.toUpperCase())}
                { label } </MButton>
      } else {
        return <MButton type="button" className={ className } onClick={ onClick }>{ label }</MButton>;
      }
    }
    return (
      <MButton className={ className }
       type={ type } 
       disabled={ disabled }
       onClick={ onClick }>{ label }</MButton>
       )
  }
}

Button.propTypes = {
  onClick: PropTypes.func
};

Accounts.ui.Button = Button;
